import java.util.Random; //imports the randomizer utility

public class Obstacles {

	private int obstacle; //variable for the obstacle
	private int obstacleRotation = 0;//variable for the rotation of the obstacle
	
	private int directionX, directionY; //variables for the x and y directions
	private int posX, posY; //variable for the x and y position
	private int speedX, speedY; //variable for the speed of the direction of the obstacle
	
	private EZImage asteroid; 							//sets the EZImage to asteroid
	
	Obstacles(int s) { 							//sets the parameters for the obstacle function
		
		speedX = s; 							//makes both the x speed and y speed the same
		speedY = s;
		direction(); 							//implements the direction function to see where the obstacel will go
		
		asteroid = EZ.addImage("asteroid.png", posX, posY); //makes the asteroid and gives it the x and y positions
		
	}
	
	private void move() { 						//makes the move function for the obstacle
		posX = posX + speedX;					//sets the x position relative to the original plus the y direction
		posY = posY + speedY;					//sets the y position relative to the original plus the y direction
		
		obstacleRotation += speedX;
		
		asteroid.rotateTo(obstacleRotation);
		asteroid.translateTo(posX, posY); 		//makes the movement of the asteroid
	}
	
	private void direction() { 					//makes the direction function for the obstacle
		Random randomGenerator = new Random(); 			//makes a new random function for direction
		int randStart = randomGenerator.nextInt(4);
		
		switch(randStart) {
			case 0:
				posX = randomGenerator.nextInt(+501);
				posY = 0;
				if (posX < 250) {
					speedX = speedX;
					speedY = speedY;
				} else {
					speedX = -speedX;
					speedY = speedY;
				}
				break;
			case 1:
				posX = randomGenerator.nextInt(+501);
				posY = 500;
				if (posX < 250) {
					speedX = speedX;
					speedY = -speedY;
				} else {
					speedX = -speedX;
					speedY = -speedY;
				}
				break;
			case 2:
				posY = randomGenerator.nextInt(+501);
				posX = 0;
				if (posY < 250) {
					speedX = speedX;
					speedY = speedY;
				} else {
					speedX = speedX;
					speedY = -speedY;
				}
				break;
			case 3:
				posY = randomGenerator.nextInt(+501);
				posX = 500;
				if (posY < 250) {
					speedX = -speedX;
					speedY = speedY;
				} else {
					speedX = -speedX;
					speedY = -speedY;
				}
				break;
			default:
				break;
		}
	}
	
	public boolean isVisible() {
		move();
		if (posX < -50 || posX > 590 || posY < -50 || posY > 590) { //new stuff ADD IT
			delete();
			return false;
		} else return true;
	}
	
	private void delete() {//function to delete the asteroid
		EZ.removeEZElement(asteroid); //removes the asteroid picture
	}
	
	public boolean isColliding(int spriteX, int spriteY) {
		if (asteroid.isPointInElement(spriteX, spriteY)){
			return true;
		} else return false;
	}
}
