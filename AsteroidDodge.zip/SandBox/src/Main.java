import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;
import java.util.Random;
import java.util.*;

public class Main {
	static int speed;
	
	public static int randSpeed() {
		Random r = new Random();
		
		speed = r.nextInt(4) + 2;
		
		if (speed == 0) {
			speed++;
		}
		
		if (speed > 4) {
			speed = speed - 2;
		}
		return speed;
	}
	
	public static void main(String[] args) throws java.io.IOException {
		
		int c = 0;
		
		int dead = 0;
		
		EZ.initialize(500, 500); 								//initializes a widow that is 500 by 500 pixels
		
		SpriteTest me = new SpriteTest(250,250,31,34,10);
		
		ArrayList<Obstacles> asteroidList = new ArrayList<Obstacles>();
		
		Obstacles asteroid = new Obstacles(randSpeed());
		Obstacles asteroid2 = new Obstacles(randSpeed());
		Obstacles asteroid3 = new Obstacles(randSpeed());
		Obstacles asteroid4 = new Obstacles(randSpeed());
		
		asteroidList.add(asteroid);
		asteroidList.add(asteroid2);
		asteroidList.add(asteroid3);
		asteroidList.add(asteroid4);
		
		Highscore sc = new Highscore();
		
		while (true) {		
			
			me.go(); 											//runs the SpriteTest
			
			for (int i = 0; i < asteroidList.size()-3; i++) {
				
				Obstacles eachAsteroid;
				
				eachAsteroid = asteroidList.get(i);
				
				//System.out.println(i);
				if (eachAsteroid.isColliding(me.spriteX(), me.spriteY())) {
					dead = 1;
				}
				if (eachAsteroid.isVisible() == false) {
					asteroidList.remove(eachAsteroid);
				
					c++;
					System.out.println(c);
					
					asteroid = new Obstacles(randSpeed());		//Just for testing
					
					asteroidList.add(asteroid);
					
				}
			}
			
			for (int i = 1; i < asteroidList.size()-2; i++) {
				
				Obstacles eachAsteroid;
				
				eachAsteroid = asteroidList.get(i);
				
				//System.out.println(i);
				if (eachAsteroid.isColliding(me.spriteX(), me.spriteY())) {
					dead = 1;
				}
				if (eachAsteroid.isVisible() == false) {
					asteroidList.remove(eachAsteroid);
				
					c++;
					System.out.println(c);
					
					asteroid = new Obstacles(randSpeed());		//Just for testing
					
					asteroidList.add(asteroid);
					
				}
			}
			
			for (int i = 2; i < asteroidList.size()-1; i++) {
				
				Obstacles eachAsteroid;
				
				eachAsteroid = asteroidList.get(i);
				
				//System.out.println(i);
				if (eachAsteroid.isColliding(me.spriteX(), me.spriteY())) {
					dead = 1;
				}
				if (eachAsteroid.isVisible() == false) {
					asteroidList.remove(eachAsteroid);
				
					c++;
					System.out.println(c);
					
					asteroid = new Obstacles(randSpeed());		//Just for testing
					
					asteroidList.add(asteroid);
					
				}
			}
			
			for (int i = 3; i < asteroidList.size(); i++) {
				
				Obstacles eachAsteroid;
				
				eachAsteroid = asteroidList.get(i);
				
				//System.out.println(i);
				if (eachAsteroid.isColliding(me.spriteX(), me.spriteY())) {
					dead = 1;
				}
				if (eachAsteroid.isVisible() == false) {
					asteroidList.remove(eachAsteroid);
				
					c++;
					System.out.println(c);
					
					asteroid = new Obstacles(randSpeed());		//Just for testing
					
					asteroidList.add(asteroid);
					
				}
			}
			
			if (dead == 1) {
				break;
			}
			
			EZ.refreshScreen(); //refreshes the screen
		
		}
		
		sc.score(c);
	}

}
