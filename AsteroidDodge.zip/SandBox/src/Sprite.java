
public class Sprite {

	void shit() {
		System.out.println("Shit");
	}
	
}
