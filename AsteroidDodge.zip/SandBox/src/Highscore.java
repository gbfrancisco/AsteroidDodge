import java.awt.Color;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class Highscore {
	private int points = 0;
	private int highScore = 0;
	
	Highscore() {
		
	}
	
	public void score(int s) throws java.io.IOException {
		points = s;
		
		Scanner scan = new Scanner(new FileReader("score.txt"));
		while (scan.hasNext()) {
			highScore = scan.nextInt();
		}
		
		if (points > highScore) {
			highScore = points;
		}
		
		scan.close();
		
		resetScore();
		
		FileWriter fw = new FileWriter("score.txt");
		fw.write(highScore + "");
		fw.close();
		
		EZ.addRectangle(250, 275, 200, 100, Color.BLACK, true);
		EZ.addText(250, 250, "Highscore: " + highScore, Color.WHITE, 25);
		EZ.addText(250, 300, "Score: " + points, Color.WHITE, 25);
	}
	
	private void resetScore() {
		if (EZInteraction.wasKeyPressed('r')) {
			highScore = 0;
		}
	}
}
