public class SpriteTest extends Sprite {
	
	EZImage spriteSheet;
	
	int x = 0;				// Position of Sprite
	int y = 0;
	int spriteWidth;		// Width of each sprite
	int spriteHeight;		// Height of each sprite
	int direction = 0;		// Direction character is walking in
	int walkSequence = 0;	// Walk sequence counter
	int cycleSteps;			// Number of steps before cycling to next animation step
	int counter = 0;		// Cycle counter
	

	SpriteTest(int startX, int startY, int width, int height, int steps) {
		x = startX;					// position of the sprite character on the screen
		y = startY;
		spriteWidth = width;		// Width of the sprite character
		spriteHeight = height;		// Height of the sprite character
		cycleSteps = steps;			// How many pixel movement steps to move before changing the sprite graphic
		spriteSheet = EZ.addImage("Test3.png", x, y);
		setImagePosition();
	}

	private void setImagePosition() {
		
		// Move the entire sprite sheet
		spriteSheet.translateTo(x, y);
		
		// Show only a portion of the sprite sheet.
		// Portion is determined by setFocus which takes 4 parameters:
		// The 1st two numbers is the top left hand corner of the focus region.
		// The 2nd two numbers is the bottom right hand corner of the focus region.
		spriteSheet.setFocus(walkSequence * spriteWidth, direction,
				walkSequence * spriteWidth + spriteWidth, direction + spriteHeight);
	}

	public void moveDown(int stepSize) {
		y = y + stepSize;

		direction = 0; //stars the movement at 0

		if ((counter % cycleSteps) == 0) { //divides the counter with the step size
			walkSequence++;
			if (walkSequence > 2)
				walkSequence = 0;
		}
		counter++;
		setImagePosition(); //changes the animation of the walk cycle
	}
	
	public void moveRight(int stepSize) {
		x = x + stepSize;
		direction = spriteHeight;

		if ((counter % cycleSteps) == 0) {
			walkSequence--;
			if (walkSequence < 0)
				walkSequence = 2;
		}
		counter++;
		setImagePosition();
	}

	public void moveLeft(int stepSize) {
		x = x - stepSize;
		direction = spriteHeight * 2;
		
		if ((counter % cycleSteps) == 0) {
			walkSequence++;
			if (walkSequence > 2)
				walkSequence = 0;
		}
		counter++;

		setImagePosition();
	}

	public void moveUp(int stepSize) {
		y = y - stepSize;
		direction = spriteHeight * 3;

		if ((counter % cycleSteps) == 0) {
			walkSequence--;
			if (walkSequence < 0)
				walkSequence = 2;
		}
		setImagePosition();

		counter++;
	}

	public int spriteX() {
		return x;
	}
	
	public int spriteY() {
		return y;
	}

	// Keyboard controls for moving the character.
	public void go() {
		if (EZInteraction.isKeyDown('w')) { //makes the sprite move left for 2 pixels if 'w' is pressed
			moveUp(2);
		} else if (EZInteraction.isKeyDown('a')) { //makes the sprite move left for 2 pixels if 'a' is pressed
			moveLeft(2);
		} else if (EZInteraction.isKeyDown('s')) { //makes the sprite move left for 2 pixels if 's' is pressed
			moveDown(2);
		} else if (EZInteraction.isKeyDown('d')) { //makes the sprite move left for 2 pixels if 'd' is pressed
			moveRight(2);
		}
	}

}
